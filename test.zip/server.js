const express = require("express");
const multer = require("multer");
const unzipper = require("unzipper");
const fs = require("fs");
const { spawn } = require("child_process");
const axios = require("axios");
const path = require("path");
const session = require("express-session");
const bcrypt = require("bcrypt");

const app = express();
// Добавьте после других глобальных переменных
let deletedUsers = []; // Список удаленных пользователей

// Функция для проверки существования пользователя
function userExists(username) {
    if (deletedUsers.includes(username)) return false;
    const userDir = path.join(__dirname, "users", username);
    return fs.existsSync(userDir) && fs.existsSync(path.join(userDir, "user.json"));
}
// Настройка сессий
app.use(session({
    secret: 'minecraft-hosting-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000 // 24 часа
    }
}));

const upload = multer({ dest: "uploads/" });

let serverProcesses = {};
let serverStatus = {};
let serverLogs = {};

app.use(express.json());
app.use(express.static("public"));

// Создаем основные папки при запуске
if (!fs.existsSync("users")) {
    fs.mkdirSync("users");
    console.log("✅ Папка users создана");
}
if (!fs.existsSync("uploads")) {
    fs.mkdirSync("uploads");
    console.log("✅ Папка uploads создана");
}

// ========== МИДЛВАР ДЛЯ ПРОВЕРКИ АВТОРИЗАЦИИ ==========
// Обновите функцию requireAuth
function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Не авторизован" });
    }
    
    // Проверяем, не был ли пользователь удален
    if (!userExists(req.session.userId)) {
        // Если пользователь удален, уничтожаем сессию
        req.session.destroy();
        return res.status(401).json({ error: "Пользователь удален" });
    }
    
    next();
}

function requireAdmin(req, res, next) {
    if (!req.session.userId || req.session.username !== 'admin') {
        return res.status(403).json({ error: "Доступ запрещен" });
    }
    next();
}

function getUserPath(username) {
    return path.join(__dirname, "users", username);
}

// ========== СОЗДАНИЕ АДМИНА ==========
async function createAdmin() {
    const adminDir = path.join(__dirname, "users", "admin");
    
    if (!fs.existsSync(adminDir)) {
        console.log("👑 Создание администратора...");
        
        try {
            fs.mkdirSync(adminDir, { recursive: true });
            fs.mkdirSync(path.join(adminDir, "server"), { recursive: true });
            
            const hashedPassword = await bcrypt.hash("admin123", 10);
            
            const adminData = {
                username: "admin",
                password: hashedPassword,
                role: "admin",
                createdAt: new Date().toISOString()
            };
            
            fs.writeFileSync(
                path.join(adminDir, "user.json"),
                JSON.stringify(adminData, null, 2)
            );
            
            console.log("=================================");
            console.log("✅ АДМИН СОЗДАН!");
            console.log("=================================");
            console.log("📝 Логин: admin");
            console.log("🔑 Пароль: admin123");
            console.log("=================================");
            
        } catch (error) {
            console.error("❌ Ошибка при создании админа:", error);
        }
    } else {
        console.log("✅ Админ уже существует");
    }
}

// ========== АВТОРИЗАЦИЯ ==========

app.post("/api/register", async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: "Заполните все поля" });
    }
    
    if (username.length < 3) {
        return res.status(400).json({ error: "Имя пользователя должно быть минимум 3 символа" });
    }
    
    if (password.length < 6) {
        return res.status(400).json({ error: "Пароль должен быть минимум 6 символов" });
    }
    
    if (username.toLowerCase() === 'admin') {
        return res.status(400).json({ error: "Это имя пользователя зарезервировано" });
    }
    
    const userDir = path.join(__dirname, "users", username);
    
    if (fs.existsSync(userDir)) {
        return res.status(400).json({ error: "Пользователь уже существует" });
    }
    
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        fs.mkdirSync(userDir, { recursive: true });
        
        const userData = {
            username,
            password: hashedPassword,
            role: 'user',
            createdAt: new Date().toISOString()
        };
        
        fs.writeFileSync(
            path.join(userDir, "user.json"),
            JSON.stringify(userData, null, 2)
        );
        
        fs.mkdirSync(path.join(userDir, "server"), { recursive: true });
        
        console.log(`✅ Создан новый пользователь: ${username}`);
        res.json({ success: true, message: "Регистрация успешна" });
        
    } catch (error) {
        console.error("Ошибка при регистрации:", error);
        res.status(500).json({ error: "Ошибка при регистрации" });
    }
});

app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: "Заполните все поля" });
    }
    
    // Проверяем, не был ли пользователь удален
    if (!userExists(username)) {
        return res.status(400).json({ error: "Неверное имя пользователя или пароль" });
    }
    
    const userDir = path.join(__dirname, "users", username);
    const userFile = path.join(userDir, "user.json");
    
    try {
        const userData = JSON.parse(fs.readFileSync(userFile, "utf8"));
        const validPassword = await bcrypt.compare(password, userData.password);
        
        if (!validPassword) {
            return res.status(400).json({ error: "Неверное имя пользователя или пароль" });
        }
        
        req.session.userId = username;
        req.session.username = username;
        req.session.role = userData.role || 'user';
        
        console.log(`✅ Пользователь вошел: ${username} (${req.session.role})`);
        res.json({ 
            success: true, 
            message: "Вход выполнен",
            username,
            role: req.session.role
        });
        
    } catch (error) {
        console.error("Ошибка при входе:", error);
        res.status(500).json({ error: "Ошибка при входе" });
    }
});

app.post("/api/logout", (req, res) => {
    const username = req.session.username;
    
    if (username && serverProcesses[username]) {
        try {
            serverProcesses[username].stdin.write("stop\n");
        } catch (e) {}
    }
    
    req.session.destroy();
    res.json({ success: true, message: "Выход выполнен" });
});

app.get("/api/check-auth", (req, res) => {
    if (req.session.userId) {
        // Проверяем, существует ли пользователь
        if (!userExists(req.session.userId)) {
            // Если пользователь удален, уничтожаем сессию
            req.session.destroy();
            return res.json({ authenticated: false });
        }
        
        res.json({ 
            authenticated: true, 
            username: req.session.username,
            role: req.session.role || 'user'
        });
    } else {
        res.json({ authenticated: false });
    }
});

// ========== СТАТУС СЕРВЕРА ==========

app.get("/api/server-status", requireAuth, (req, res) => {
    const username = req.session.username;
    const isRunning = !!serverProcesses[username];
    
    res.json({
        running: isRunning,
        status: isRunning ? "running" : "stopped"
    });
});

app.get("/api/server-logs", requireAuth, (req, res) => {
    const username = req.session.username;
    res.json({ logs: serverLogs[username] || [] });
});

// ========== АДМИН ПАНЕЛЬ ==========

app.get("/api/admin/users", requireAdmin, (req, res) => {
    try {
        const users = fs.readdirSync("users")
            .filter(user => fs.statSync(path.join("users", user)).isDirectory())
            .map(user => {
                try {
                    const userData = JSON.parse(fs.readFileSync(path.join("users", user, "user.json"), "utf8"));
                    const serverPath = path.join("users", user, "server");
                    
                    return {
                        username: user,
                        role: userData.role || 'user',
                        createdAt: userData.createdAt,
                        serverRunning: !!serverProcesses[user],
                        filesCount: fs.existsSync(serverPath) ? fs.readdirSync(serverPath).length : 0
                    };
                } catch (e) {
                    return {
                        username: user,
                        role: 'unknown',
                        error: true
                    };
                }
            });
        
        res.json(users);
    } catch (error) {
        console.error("Ошибка при получении списка пользователей:", error);
        res.status(500).json({ error: "Ошибка при получении списка пользователей" });
    }
});

app.post("/api/admin/delete-user", requireAdmin, async (req, res) => {
    const { username } = req.body;
    
    console.log(`🗑️ Запрос на удаление пользователя: ${username}`);
    
    if (!username || username === 'admin') {
        return res.status(400).json({ error: "Нельзя удалить админа" });
    }
    
    const userDir = path.join(__dirname, "users", username);
    
    try {
        // 1. Добавляем в список удаленных (чтобы сразу заблокировать)
        if (!deletedUsers.includes(username)) {
            deletedUsers.push(username);
        }
        
        // 2. ОСТАНАВЛИВАЕМ ПРОЦЕСС СЕРВЕРА
        if (serverProcesses[username]) {
            console.log(`⏹️ Останавливаем процесс сервера для ${username}`);
            try {
                if (serverProcesses[username].stdin) {
                    serverProcesses[username].stdin.write("stop\n");
                }
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                if (serverProcesses[username]) {
                    serverProcesses[username].kill('SIGKILL');
                }
            } catch (e) {
                console.log("Ошибка при остановке процесса:", e);
            }
            
            delete serverProcesses[username];
        }
        
        // 3. ОЧИЩАЕМ ВСЕ ДАННЫЕ ИЗ ПАМЯТИ
        delete serverProcesses[username];
        delete serverStatus[username];
        delete serverLogs[username];
        
        // 4. УДАЛЯЕМ ФАЙЛЫ С ДИСКА
        console.log(`📁 Удаляем файлы пользователя: ${userDir}`);
        
        if (fs.existsSync(userDir)) {
            // Используем принудительное удаление
            fs.rmSync(userDir, { 
                recursive: true, 
                force: true,
                maxRetries: 5,
                retryDelay: 100
            });
            console.log(`✅ Папка пользователя удалена: ${userDir}`);
        }
        
        // 5. Удаляем из списка удаленных через 5 минут (для очистки памяти)
        setTimeout(() => {
            const index = deletedUsers.indexOf(username);
            if (index > -1) {
                deletedUsers.splice(index, 1);
            }
        }, 5 * 60 * 1000);
        
        console.log(`✅ Пользователь ${username} полностью удален`);
        res.json({ success: true, message: "Пользователь успешно удален" });
        
    } catch (error) {
        console.error("❌ Ошибка при удалении пользователя:", error);
        
        // В случае ошибки все равно пытаемся очистить память
        try {
            delete serverProcesses[username];
            delete serverStatus[username];
            delete serverLogs[username];
        } catch (e) {}
        
        res.status(500).json({ error: "Ошибка при удалении пользователя" });
    }
});

app.post("/api/admin/stop-server", requireAdmin, (req, res) => {
    const { username } = req.body;
    
    if (!username || !serverProcesses[username]) {
        return res.json({ success: false, message: "Сервер не запущен" });
    }
    
    try {
        serverProcesses[username].stdin.write("stop\n");
        res.json({ success: true, message: "Сервер останавливается" });
    } catch (error) {
        res.status(500).json({ error: "Ошибка при остановке сервера" });
    }
});

// ========== ФАЙЛЫ ПОЛЬЗОВАТЕЛЯ ==========

app.get("/api/files", requireAuth, (req, res) => {
    const username = req.session.username;
    const userServerPath = path.join(getUserPath(username), "server");
    
    try {
        if (!fs.existsSync(userServerPath)) {
            fs.mkdirSync(userServerPath, { recursive: true });
        }
        
        let files = [];
        try {
            files = fs.readdirSync(userServerPath).map(file => {
                const filePath = path.join(userServerPath, file);
                const stats = fs.statSync(filePath);
                return {
                    name: file,
                    path: file,
                    size: stats.size,
                    modified: stats.mtime,
                    type: getFileType(file)
                };
            });
        } catch (err) {
            console.log("Ошибка чтения папки сервера:", err);
        }
        
        const hasServerJar = files.some(f => f.name === "server.jar");
        
        if (!files.some(f => f.name === "server.properties")) {
            const defaultProps = `# Minecraft server properties
max-players=20
gamemode=survival
difficulty=easy
pvp=true
spawn-animals=true
spawn-monsters=true
online-mode=true
allow-nether=true
view-distance=10
motd=${username}'s Server
server-port=25565
`;
            fs.writeFileSync(path.join(userServerPath, "server.properties"), defaultProps);
            files.push({
                name: "server.properties",
                path: "server.properties",
                size: defaultProps.length,
                modified: new Date(),
                type: "properties"
            });
        }
        
        if (!files.some(f => f.name === "eula.txt")) {
            const defaultEula = "eula=false\n# Измените false на true, чтобы принять лицензионное соглашение";
            fs.writeFileSync(path.join(userServerPath, "eula.txt"), defaultEula);
            files.push({
                name: "eula.txt",
                path: "eula.txt",
                size: defaultEula.length,
                modified: new Date(),
                type: "text"
            });
        }
        
        res.json(files);
        
    } catch (error) {
        console.error("Ошибка при получении списка файлов:", error);
        res.status(500).json({ error: "Ошибка при получении списка файлов" });
    }
});

app.get("/api/file/:filename", requireAuth, (req, res) => {
    const username = req.session.username;
    const filename = req.params.filename;
    
    if (filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
        return res.status(400).send("Недопустимое имя файла");
    }
    
    const filePath = path.join(getUserPath(username), "server", filename);
    
    try {
        if (!fs.existsSync(filePath)) {
            return res.status(404).send("Файл не найден");
        }
        
        const content = fs.readFileSync(filePath, "utf8");
        res.send(content);
        
    } catch (error) {
        console.error(`Ошибка при чтении файла ${filename}:`, error);
        res.status(500).send("Ошибка при чтении файла");
    }
});

app.post("/api/file/:filename", requireAuth, (req, res) => {
    const username = req.session.username;
    const filename = req.params.filename;
    const { content } = req.body;
    
    if (filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
        return res.status(400).send("Недопустимое имя файла");
    }
    
    if (filename === "server.jar") {
        return res.status(400).send("Нельзя редактировать server.jar через редактор");
    }
    
    const filePath = path.join(getUserPath(username), "server", filename);
    
    try {
        fs.writeFileSync(filePath, content);
        console.log(`Файл ${filename} сохранен для ${username}`);
        res.send("Файл сохранен");
    } catch (error) {
        console.error(`Ошибка при сохранении файла ${filename}:`, error);
        res.status(500).send("Ошибка при сохранении файла");
    }
});

// ========== PAPER ==========

app.get("/api/paper-versions", async (req, res) => {
    try {
        const response = await axios.get("https://api.papermc.io/v2/projects/paper");
        
        if (response.data && response.data.versions) {
            const versions = response.data.versions.reverse();
            res.json(versions);
        } else {
            res.status(500).json({ error: "Неверная структура ответа от API" });
        }
    } catch (error) {
        console.error("Ошибка при получении версий Paper:", error.message);
        res.status(500).json({ error: "Не удалось получить версии Paper" });
    }
});

app.post("/download-paper", requireAuth, async (req, res) => {
    const username = req.session.username;
    const { version } = req.body;
    
    if (!version) return res.status(400).send("Версия не указана");

    try {
        console.log(`Скачивание Paper версии ${version} для ${username}...`);
        
        const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${version}/builds`);
        
        if (!buildsRes.data || !buildsRes.data.builds || buildsRes.data.builds.length === 0) {
            return res.status(404).send("Сборки для этой версии не найдены");
        }
        
        const latestBuild = buildsRes.data.builds[buildsRes.data.builds.length - 1];
        const fileName = latestBuild.downloads.application.name;
        const downloadUrl = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${latestBuild.build}/downloads/${fileName}`;

        const userServerPath = path.join(getUserPath(username), "server");
        
        const jarPath = path.join(userServerPath, "server.jar");
        if (fs.existsSync(jarPath)) {
            fs.unlinkSync(jarPath);
        }

        const writer = fs.createWriteStream(jarPath);
        const response = await axios({
            method: "get",
            url: downloadUrl,
            responseType: "stream",
        });

        response.data.pipe(writer);

        writer.on("finish", () => {
            console.log(`Paper ${version} успешно скачан для ${username}`);
            res.send(`Ядро Paper ${version} (build ${latestBuild.build}) успешно скачано!`);
        });

        writer.on("error", (err) => {
            console.error("Ошибка при сохранении файла:", err);
            res.status(500).send("Ошибка при сохранении файла");
        });
    } catch (error) {
        console.error("Ошибка при скачивании Paper:", error.message);
        res.status(500).send(`Ошибка при скачивании Paper: ${error.message}`);
    }
});

// ========== ПОИСК ПЛАГИНОВ ==========

app.get("/search-plugins", async (req, res) => {
    const query = req.query.q;
    if (!query) return res.json([]);

    try {
        const response = await axios.get("https://api.modrinth.com/v2/search", {
            params: {
                query: query,
                limit: 10,
                facets: JSON.stringify([["project_type:plugin"]])
            },
        });

        const plugins = response.data.hits.map(hit => ({
            title: hit.title,
            description: hit.description,
            versions: hit.versions || [],
            icon_url: hit.icon_url,
            project_id: hit.project_id,
            downloads: hit.downloads,
            author: hit.author,
        }));

        res.json(plugins);
    } catch (error) {
        console.error("Ошибка поиска плагинов:", error.message);
        res.status(500).json({ error: "Ошибка поиска плагинов" });
    }
});

// ========== ЗАПУСК СЕРВЕРА ==========

app.post("/start", requireAuth, (req, res) => {
    const username = req.session.username;
    const userServerPath = path.join(getUserPath(username), "server");
    
    if (serverProcesses[username]) {
        return res.json({ success: false, message: "Сервер уже запущен" });
    }

    if (!fs.existsSync(path.join(userServerPath, "server.jar"))) {
        return res.json({ success: false, message: "Сначала скачайте ядро Paper" });
    }

    console.log(`Запуск сервера для ${username}...`);
    
    if (!serverLogs[username]) {
        serverLogs[username] = [];
    }
    
    serverProcesses[username] = spawn("java", ["-jar", "server.jar", "nogui"], {
        cwd: userServerPath,
        stdio: "pipe",
    });

    serverStatus[username] = "running";
    
    addLog(username, "Сервер запускается...");

    serverProcesses[username].stdout.on("data", (data) => {
        const text = data.toString();
        addLog(username, text);
    });

    serverProcesses[username].stderr.on("data", (data) => {
        const text = data.toString();
        addLog(username, "[ERROR] " + text);
    });

    serverProcesses[username].on("close", () => {
        delete serverProcesses[username];
        serverStatus[username] = "stopped";
        addLog(username, "Сервер остановлен");
    });

    res.json({ success: true, message: "Сервер запускается..." });
});

app.post("/stop", requireAuth, (req, res) => {
    const username = req.session.username;
    
    if (!serverProcesses[username]) {
        return res.json({ success: false, message: "Сервер не запущен" });
    }
    
    console.log(`Остановка сервера для ${username}...`);
    addLog(username, "Остановка сервера...");
    serverProcesses[username].stdin.write("stop\n");
    
    res.json({ success: true, message: "Остановка..." });
});

app.post("/command", requireAuth, (req, res) => {
    const username = req.session.username;
    
    if (!serverProcesses[username]) {
        return res.json({ success: false, message: "Сервер не запущен" });
    }
    
    serverProcesses[username].stdin.write(req.body.command + "\n");
    res.json({ success: true });
});

// ========== ЗАГРУЗКА ZIP ==========

app.post("/upload", requireAuth, upload.single("file"), async (req, res) => {
    const username = req.session.username;
    
    if (!req.file) return res.status(400).send("Файл не найден");

    const zipPath = req.file.path;
    const userServerPath = path.join(getUserPath(username), "server");

    fs.createReadStream(zipPath)
        .pipe(unzipper.Extract({ path: userServerPath }))
        .on("close", () => {
            fs.unlinkSync(zipPath);
            console.log(`ZIP распакован для ${username}`);
            res.send("ZIP загружен и распакован!");
        })
        .on("error", (err) => {
            console.error("Ошибка распаковки ZIP:", err);
            res.status(500).send("Ошибка при распаковке ZIP");
        });
});

// ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========

function getFileType(filename) {
    if (filename.endsWith('.properties')) return 'properties';
    if (filename.endsWith('.txt')) return 'text';
    if (filename.endsWith('.yml') || filename.endsWith('.yaml')) return 'yaml';
    if (filename.endsWith('.jar')) return 'jar';
    if (filename.endsWith('.json')) return 'json';
    return 'unknown';
}

function addLog(username, text) {
    if (!serverLogs[username]) {
        serverLogs[username] = [];
    }
    serverLogs[username].push(text);
    if (serverLogs[username].length > 1000) {
        serverLogs[username] = serverLogs[username].slice(-1000);
    }
}

// ========== СТРАНИЦЫ ==========

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/admin', (req, res) => {
    if (!req.session.userId || req.session.username !== 'admin') {
        res.redirect('/');
    } else {
        res.sendFile(path.join(__dirname, 'public', 'admin.html'));
    }
});

app.get('/', (req, res) => {
    if (!req.session.userId) {
        res.redirect('/login');
    } else {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    }
});
// Добавьте после app.post("/api/admin/stop-server", ...)

app.get("/api/admin/stats", requireAdmin, (req, res) => {
    try {
        const users = fs.readdirSync("users").filter(user => 
            fs.statSync(path.join("users", user)).isDirectory()
        );
        
        let totalSize = 0;
        users.forEach(user => {
            const serverPath = path.join("users", user, "server");
            if (fs.existsSync(serverPath)) {
                const files = fs.readdirSync(serverPath);
                files.forEach(file => {
                    const filePath = path.join(serverPath, file);
                    const stats = fs.statSync(filePath);
                    totalSize += stats.size;
                });
            }
        });
        
        res.json({
            totalUsers: users.length,
            runningServers: Object.keys(serverProcesses).length,
            totalSize: formatBytes(totalSize),
            onlinePlayers: 0 // TODO: подсчет игроков
        });
    } catch (error) {
        console.error("Ошибка при получении статистики:", error);
        res.status(500).json({ error: "Ошибка при получении статистики" });
    }
});

// Добавьте функцию formatBytes где-нибудь в конце файла
function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}
// ========== ЗАПУСК ==========

createAdmin().then(() => {
    app.listen(3000, () => {
        console.log("=================================");
        console.log("🚀 Сервер запущен!");
        console.log("🌐 http://localhost:3000");
       console.log("=================================");
   });
});
