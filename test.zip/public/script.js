// Глобальные переменные
let currentUsername = '';
let userRole = 'user';
let currentFile = null;
let statusUpdateInterval = null;
let logUpdateInterval = null;

// Проверка авторизации при загрузке
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    
    // Обработчик формы загрузки ZIP
    const uploadForm = document.getElementById("uploadForm");
    if (uploadForm) {
        uploadForm.onsubmit = async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await fetch("/upload", {
                method: "POST",
                body: formData
            });
            alert("ZIP загружен!");
            loadFileList();
        };
    }
});

// Проверка авторизации
async function checkAuth() {
    try {
        const res = await fetch('/api/check-auth');
        const data = await res.json();
        
        if (!data.authenticated) {
            window.location.href = '/login.html';
            return;
        }
        
        currentUsername = data.username;
        userRole = data.role || 'user';
        
        // Обновляем информацию о пользователе
        const userInfo = document.getElementById('userInfo');
        if (userInfo) {
            userInfo.innerHTML = `
                <div class="user-badge">
                    <span class="user-icon">${userRole === 'admin' ? '👑' : '👤'}</span>
                    <span class="user-name">${data.username}</span>
                    ${userRole === 'admin' ? '<span class="admin-label">admin</span>' : ''}
                </div>
            `;
        }
        
        // Показываем кнопку админ-панели если админ
        const adminButton = document.getElementById('adminButtonContainer');
        if (adminButton && userRole === 'admin') {
            adminButton.style.display = 'block';
        }
        
        // Запускаем обновление статуса и логов
        startStatusUpdates();
        loadLogs();
        updateServerStatus();
        
    } catch (error) {
        console.error("Ошибка проверки авторизации:", error);
    }
}

// Функция выхода
async function logout() {
    stopStatusUpdates();
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login.html';
}

// ========== СТАТУС И ЛОГИ ==========

function startStatusUpdates() {
    // Обновляем статус каждые 2 секунды
    if (statusUpdateInterval) clearInterval(statusUpdateInterval);
    statusUpdateInterval = setInterval(updateServerStatus, 2000);
    
    // Обновляем логи каждые 3 секунды
    if (logUpdateInterval) clearInterval(logUpdateInterval);
    logUpdateInterval = setInterval(loadLogs, 3000);
}

function stopStatusUpdates() {
    if (statusUpdateInterval) {
        clearInterval(statusUpdateInterval);
        statusUpdateInterval = null;
    }
    if (logUpdateInterval) {
        clearInterval(logUpdateInterval);
        logUpdateInterval = null;
    }
}

async function updateServerStatus() {
    try {
        const res = await fetch('/api/server-status');
        const data = await res.json();
        
        const statusSpan = document.getElementById("status");
        if (statusSpan) {
            statusSpan.innerHTML = data.running ? "🟢 Запущен" : "🔴 Остановлен";
        }
    } catch (error) {
        console.error("Ошибка получения статуса:", error);
    }
}

async function loadLogs() {
    try {
        const res = await fetch('/api/server-logs');
        const data = await res.json();
        
        const consoleDiv = document.getElementById("console");
        if (consoleDiv && data.logs && data.logs.length > 0) {
            consoleDiv.innerHTML = data.logs.join("<br>");
            consoleDiv.scrollTop = consoleDiv.scrollHeight;
        }
    } catch (error) {
        console.error("Ошибка загрузки логов:", error);
    }
}

// ========== УПРАВЛЕНИЕ ВКЛАДКАМИ ==========

function showTab(tab) {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.getElementById(tab + "Tab").classList.add("active");
    
    // Загружаем данные в зависимости от вкладки
    if (tab === 'core') {
        loadVersions();
    } else if (tab === 'files') {
        loadFileList();
    } else if (tab === 'players') {
        loadPlayers();
    }
}

// ========== УПРАВЛЕНИЕ СЕРВЕРОМ ==========

async function start() {
    const res = await fetch("/start", { 
        method: "POST",
        headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();
    
    if (!data.success) {
        alert(data.message);
    }
}

async function stop() {
    await fetch("/stop", { 
        method: "POST",
        headers: { "Content-Type": "application/json" }
    });
}

async function sendCommand() {
    const cmdInput = document.getElementById("commandInput");
    const cmd = cmdInput.value;
    if (!cmd) return;
    
    await fetch("/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: cmd })
    });
    cmdInput.value = "";
}

async function loadPlayers() {
    const list = document.getElementById("playersList");
    if (list) {
        list.innerHTML = "<li>Функция в разработке</li>";
    }
}

// ========== УПРАВЛЕНИЕ ФАЙЛАМИ ==========

async function loadFileList() {
    console.log("Загрузка списка файлов...");
    const fileListElement = document.getElementById("fileList");
    
    if (!fileListElement) return;
    
    try {
        const res = await fetch("/api/files");
        
        if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const files = await res.json();
        console.log("Получены файлы:", files);
        
        if (files.error) {
            fileListElement.innerHTML = `<li class="error">Ошибка: ${files.error}</li>`;
            return;
        }
        
        if (!files || files.length === 0) {
            fileListElement.innerHTML = "<li class='info'>Нет файлов для отображения</li>";
            return;
        }
        
        fileListElement.innerHTML = files.map(file => {
            let icon = "📄";
            if (file.type === 'properties') icon = "⚙️";
            if (file.type === 'jar') icon = "☕";
            if (file.name === 'eula.txt') icon = "📜";
            
            return `
                <li class="file-item ${file.name === currentFile ? 'active' : ''}" onclick="loadFile('${file.name}')">
                    <span class="file-icon">${icon}</span>
                    <span class="file-name">${file.name}</span>
                    ${file.exists === false ? '<span class="file-badge">не скачан</span>' : ''}
                </li>
            `;
        }).join("");
        
    } catch (error) {
        console.error("Ошибка загрузки списка файлов:", error);
        fileListElement.innerHTML = "<li class='error'>Ошибка загрузки списка файлов</li>";
    }
}

async function loadFile(filename) {
    console.log("Загрузка файла:", filename);
    
    if (filename === "server.jar") {
        alert("Нельзя редактировать server.jar через редактор");
        return;
    }
    
    try {
        const res = await fetch(`/api/file/${encodeURIComponent(filename)}`);
        
        if (!res.ok) {
            const error = await res.text();
            throw new Error(error);
        }
        
        const content = await res.text();
        
        const fileNameElement = document.getElementById("currentFileName");
        if (fileNameElement) fileNameElement.textContent = filename;
        
        const textarea = document.getElementById("fileContent");
        if (textarea) {
            textarea.value = content;
            textarea.readOnly = false;
        }
        
        const saveBtn = document.getElementById("saveBtn");
        if (saveBtn) saveBtn.style.display = "inline-block";
        
        currentFile = filename;
        
        // Подсвечиваем активный файл
        document.querySelectorAll(".file-item").forEach(item => {
            item.classList.remove("active");
            if (item.textContent.includes(filename)) {
                item.classList.add("active");
            }
        });
        
    } catch (error) {
        console.error("Ошибка при загрузке файла:", error);
        alert("Ошибка при загрузке файла: " + error.message);
    }
}

async function saveFile() {
    if (!currentFile) return;
    
    const content = document.getElementById("fileContent").value;
    
    try {
        const res = await fetch(`/api/file/${encodeURIComponent(currentFile)}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content })
        });
        
        if (res.ok) {
            alert("✅ Файл успешно сохранен!");
        } else {
            const error = await res.text();
            alert("❌ Ошибка при сохранении файла: " + error);
        }
    } catch (error) {
        console.error("Ошибка при сохранении файла:", error);
        alert("❌ Ошибка при сохранении файла");
    }
}

// ========== PAPER VERSIONS ==========

async function loadVersions() {
    const select = document.getElementById("versionSelect");
    if (!select) return;
    
    select.innerHTML = "<option>Загрузка версий...</option>";
    
    try {
        const res = await fetch("/api/paper-versions");
        
        if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const versions = await res.json();
        
        if (versions.error) {
            select.innerHTML = `<option>Ошибка: ${versions.error}</option>`;
            return;
        }
        
        if (versions.length === 0) {
            select.innerHTML = "<option>Версии не найдены</option>";
            return;
        }
        
        // Фильтруем стабильные версии
        const stableVersions = versions.filter(v => 
            !v.includes('pre') && !v.includes('rc') && !v.includes('SNAPSHOT')
        );
        
        select.innerHTML = stableVersions.map(v => 
            `<option value="${v}">${v}</option>`
        ).join("");
        
    } catch (e) {
        console.error("Ошибка загрузки версий:", e);
        select.innerHTML = "<option>Ошибка загрузки версий</option>";
    }
}

async function downloadPaper() {
    const version = document.getElementById("versionSelect").value;
    const msgDiv = document.getElementById("coreMessage");
    
    if (!version || version.includes('Загрузка') || version.includes('Ошибка')) {
        msgDiv.textContent = "Выберите версию для скачивания";
        return;
    }
    
    msgDiv.textContent = "Скачивание...";
    msgDiv.style.color = "#b5b9ff";

    try {
        const res = await fetch("/download-paper", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ version })
        });
        
        const text = await res.text();
        
        if (res.ok) {
            msgDiv.textContent = text;
            msgDiv.style.color = "#4ade80";
        } else {
            msgDiv.textContent = "Ошибка: " + text;
            msgDiv.style.color = "#f87171";
        }
    } catch (error) {
        msgDiv.textContent = "Ошибка соединения с сервером";
        msgDiv.style.color = "#f87171";
    }
}

// ========== ПОИСК ПЛАГИНОВ ==========

let searchTimeout;

function searchPlugins() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(async () => {
        const query = document.getElementById("pluginSearch").value;
        const resultsDiv = document.getElementById("pluginResults");
        
        if (!query || query.length < 3) {
            resultsDiv.innerHTML = "<p>Введите минимум 3 символа для поиска</p>";
            return;
        }

        resultsDiv.innerHTML = "<p>Поиск...</p>";
        
        try {
            const res = await fetch(`/search-plugins?q=${encodeURIComponent(query)}`);
            const plugins = await res.json();
            renderPlugins(plugins);
        } catch (error) {
            console.error("Ошибка поиска:", error);
            resultsDiv.innerHTML = "<p>Ошибка при поиске плагинов</p>";
        }
    }, 500);
}

function renderPlugins(plugins) {
    const container = document.getElementById("pluginResults");
    
    if (!plugins || plugins.length === 0) {
        container.innerHTML = "<p>Ничего не найдено</p>";
        return;
    }

    container.innerHTML = plugins.map(p => `
        <div class="plugin-card">
            <img src="${p.icon_url || 'https://via.placeholder.com/64?text=Plugin'}" alt="icon" width="64" height="64">
            <div class="plugin-info">
                <h3>${p.title}</h3>
                <p>${p.description || 'Нет описания'}</p>
                <p><small>Автор: ${p.author || 'Неизвестен'}</small></p>
                <p><small>Скачиваний: ${p.downloads?.toLocaleString() || 'Н/Д'}</small></p>
                <div class="versions">
                    <strong>Подходит для:</strong> 
                    ${p.versions && p.versions.length > 0 
                        ? p.versions.slice(0, 5).join(', ') + (p.versions.length > 5 ? '...' : '')
                        : 'Не указано'}
                </div>
            </div>
        </div>
    `).join("");
}